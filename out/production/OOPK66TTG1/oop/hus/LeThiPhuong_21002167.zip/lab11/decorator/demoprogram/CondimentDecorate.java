package oop.hus.lab11.decorator.demoprogram;

public abstract class CondimentDecorate extends Beverage {
    public abstract String getDescription();
}
