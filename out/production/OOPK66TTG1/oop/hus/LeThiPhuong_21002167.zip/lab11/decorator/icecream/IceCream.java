package oop.hus.lab11.decorator.icecream;

public interface IceCream {
    String getDescription();
    int cost();
}
