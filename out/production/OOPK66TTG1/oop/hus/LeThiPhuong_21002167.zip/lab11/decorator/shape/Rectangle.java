package oop.hus.lab11.decorator.shape;

public class Rectangle implements Shape{
    @Override
    public void draw() {
        System.out.println("rectangle");
    }
}
