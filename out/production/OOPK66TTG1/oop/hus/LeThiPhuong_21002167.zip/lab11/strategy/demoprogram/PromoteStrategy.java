package oop.hus.lab11.strategy.demoprogram;

public interface PromoteStrategy {
    double doDiscount(double price);
    String getType();
}
