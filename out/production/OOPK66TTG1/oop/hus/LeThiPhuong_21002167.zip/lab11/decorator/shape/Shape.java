package oop.hus.lab11.decorator.shape;

public interface Shape {
    void draw();
}
