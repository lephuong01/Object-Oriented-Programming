package oop.hus.lab11.decorator.demoprogram;

public class HouseBlend extends Beverage {
    public HouseBlend() {
        description = "HouseBlend";
    }

    @Override
    public double cost() {
        return 1;
    }
}
