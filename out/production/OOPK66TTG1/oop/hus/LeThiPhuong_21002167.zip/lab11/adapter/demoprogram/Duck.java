package oop.hus.lab11.adapter.demoprogram;

public interface Duck {
    void quack();
    void fly();
}
