package oop.hus.lab11.decorator.shape;

public abstract class ShapeDecorate implements Shape {
    Shape shape;

    public ShapeDecorate(Shape shape) {
        this.shape = shape;
    }

    public void draw() {
        shape.draw();
    }
}
