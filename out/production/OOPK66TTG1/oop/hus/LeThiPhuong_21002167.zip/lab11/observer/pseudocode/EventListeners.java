package oop.hus.lab11.observer.pseudocode;

public interface EventListeners {
    void update(String filename);
}
