package oop.hus.lab11.strategy.sort;

public interface Sorter {
    void sort(int[] data);
}
