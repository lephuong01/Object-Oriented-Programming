package oop.hus.lab11.decorator.demoprogram;

public class DarkRoast extends Beverage {
    public DarkRoast() {
        description = "DarkRoast";
    }

    @Override
    public double cost() {
        return 3;
    }
}
