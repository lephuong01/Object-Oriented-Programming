package oop.hus.lab11.strategy.pseudocode;

public interface Strategy {
    int execute(int a, int b);

}
