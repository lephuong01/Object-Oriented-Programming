package oop.hus.lab11.observer.structure;

public interface MyObserver {
    void update(int newData);
}
