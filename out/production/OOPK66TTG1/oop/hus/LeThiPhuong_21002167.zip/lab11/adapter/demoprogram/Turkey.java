package oop.hus.lab11.adapter.demoprogram;

public interface Turkey {
    void gobble();

    void fly();
}